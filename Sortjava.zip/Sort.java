class Sort{
  //*NOTE: mergeSort,insertion, and quick sort are modified based on lecture note codes (credit)
  public static void main(String [] args)
  {
    System.out.println("Hello World");
  }
  public Sort(){
    System.out.println("Entering Sort program");
  }
  public void reverse(int[] input)//MAJOR HELPER METHOD
  {
    int[] hi= new int[input.length]; //an array to store the reverse of input array
    //reverse array to descending order
    int i = 0;
    for(int j = input.length-1; j>=0; j--) 
    {
      hi[i]=input[j]; //reverse/flip 
      i++;
    }
    for(int a = 0; a<input.length;a++)
    {
      input[a] = hi[a]; //transfer the sorted data back into input
    }
    return;
  }

  public void mergeSort(int[] input){ //MAIN METHOD
    int[] temp = new int[input.length]; //a copy array that will copy back values to input array
    myMergeSort(input, temp, 0, input.length -1);  //call helper method
    reverse(input); //will reverse the input array to make it sorted in descending order
    
  }

  public void quickSort(int[] input){ //MAIN METHOD
    myQuickSort(input,0,input.length-1); //call helper method myQuickSort on the entire array
    reverse(input); //will reverse the input array to make it sorted in descending order
  }
  public void myQuickSort(int[] arr, int first, int last) //HELPER
  { //dividing process
    if(first>=last) //size one/ only one element left
    {
      return;
    }
    else
    {
      int split = partition(arr,first,last);  //get the index at where left and right arrays will be made
      //keep dividing and
      myQuickSort(arr,first,split); //left 
      myQuickSort(arr,split+1,last); //right
    }
  }
  public int partition(int[] arr, int first, int last) //HELPER
  //partition, divide the arrays into left and right but also SORTING
  {
    int pivot = arr[(first+last)/2]; //middle is pivot 
    int i = first -1; //index going from left to right
    int j = last +1; // index going from right to left
    while(true){
      do{
        i++;
      }while(arr[i]<pivot); //advance i to right as long as the value in that ith position is less than the pivot (LEFT ARRAY SET UP)
      do{
        j--;//advance j to left as long as the value in that jth position is greater than the pivot (RIGHT array set up)
      }while(arr[j]>pivot); 
      if(i<j) //after discover a value that out of place 
      {
        //swap the values so that each belong in the correct subarray
        int h = arr[i];
        int b = arr[j];
        arr[i] = b;
        arr[j] = h;
      }
      else
      {
        return j; //arr[j] at end of left array 
        //return this value so that this index will be saved in the making of subarrays 
      }
    }
  }
  public void upgradedQuickSort(int[] input, int d, int k) //MAIN METHOD
  {
    //ALOHA
    int dep = 0;
    int know = input.length; //originally element numbers are equal to input.length
    if(d==0 |k==input.length)
    {
      System.out.println("**MESSAGE: this is displayed because either the given depth is zero or the k input is equal to the array's length**\n"); //doesn't work
    }
    if(d<0 | (k<0)| k>input.length)
    {
      //cannot do this because k elements cannot be less than 0 and cannot be greater than array's length and d cannot be less than 0 because depth is always greater than 0;
      System.out.println("!!!WARNING: cannot process method because either d or k user input is INVALID!!! RETRY PLEASE\n");
      return;
      //will not work
    }
    upQS(input,d,k,dep,know,0,input.length-1); // CALL helper method
    reverse(input); //reverse the array
    
  }
  public void upQS(int[] arr, int depth, int kel, int dNow, int kNow, int first, int last)
  {
    int[] merge = new int[arr.length]; 
    
  /*  if(first>=last) //another base case where only one element exist
    {
      return;
    }*/

    int split = partition(arr,first,last);
    if(dNow==depth) //will go to mergesort if depth limit is reached
    {
      int [] temp_1 = new int[arr.length]; //left copy of subarray
      int[] temp = new int[arr.length]; //right copy of subarray
      myMergeSort(arr, temp_1, first, split);  //call helper method to sort left
      myMergeSort(arr, temp, split+1, last); //call helper to sort right
      
      return;
      
    }
    if (kNow<=kel) // will go to insertion sort if less than kel (k) elements
    {
      for(int i = 0; i<=arr.length-1; i++) //stored value of arr to another one
      {
        merge[i] = arr[i];
      }// switch to insertion sort once less than k elements is reached
      insertionSortCopy(merge); //call insertionSort ONCE on the entire ARRAY MERGE
      for(int j = 0; j<=arr.length-1; j++) //copy back
      {
        arr[j] = merge[j];
      }
      return; 
    }
    else //CONTINUE quick sort
    {
      //will increment the depth by one and kNow/2 (because divided in half once again)
      upQS(arr,depth, kel, dNow+1, kNow/2, first,split); //left
      upQS(arr,depth, kel, dNow+1, kNow/2, split+1,last); //right
    }

    }
  public void insertionSortCopy(int[] input){
    int[] array3 = new int[input.length]; //another copy of the input array
    for(int i = 0; i<input.length;i++)
    {
      array3[i]=input[i];
    }
    //after transfered data from input to array3
    for(int start = 1; start<array3.length; start++) //set the current position
    {
      int num = array3[start];
      for(int left = start; (left>0) && (num<array3[left-1]); left--) //check left as long as the left index is greater than 0 because left-1 always >=0.
      {
        array3[left] = array3[left-1]; //sliding one to the right
        array3[left-1] = num;
     
      }
  
    }
    //transfer sorted array3 to input
    for(int i = 0; i<input.length;i++)
    {
      input[i]=array3[i];
    }
 ///This is for the upgradedQuickSort ONLY because i dont want to flip the array in the insertionsort part, need to do that in the main upgradedQUickSort method.
  }

  public void insertionSort(int[] input){
    int[] array3 = new int[input.length]; //another copy of the input array
    for(int i = 0; i<input.length;i++)
    {
      array3[i]=input[i];
    }
    //after transfered data from input to array3
    for(int start = 1; start<array3.length; start++) //set the current position
    {
      int num = array3[start];
      for(int left = start; (left>0) && (num<array3[left-1]); left--) //check left as long as the left index is greater than 0 because left-1 always >=0.
      {
        array3[left] = array3[left-1]; //sliding one to the right
        array3[left-1] = num;
     
      }
  
    }
    //transfer sorted array3 to input
    for(int i = 0; i<input.length;i++)
    {
      input[i]=array3[i];
    }
    reverse(input); //the input is pointed to the completed reversed and sorted array
  }
  
  public int select(int[]input, int k){
    int val = 0;
    int index = 0;
    int count=0;
    int large= 0;
    int[] sort= input;
    while(count<=sort.length-1)
    {
    large = sort[count]; // initlly largest is the first element of unsorted region
    index = count; //index is the first element
    for(int first = count; first<sort.length-1; first++) //find largest in unsorted region
    {
      if(large<sort[first+1])
      {
        index= first+1; // the index with largest num
        large = sort[index];
      }
    }
    sort[index] = sort[count]; //swap the first value into the position of largest
    sort[count] = large;//assign largest to beginning
    count++; //move ahead into the unsorted region by one
    }
    //sorted array and value
    val = sort[k];
  /*  for(int g = 0; g<sort.length; g++) //print out the array 
    {
      System.out.print(sort[g] + " ");
    } */
    return val;
  }
  public void myMergeSort(int[] input, int[] temp, int start, int end)
  {
    //helper method for merge sort #1
    if(start>=end)
    {
      return; //when cannot devide anyy more
    }
    else
    {

      int middle = (start+end)/2; //split
      //sort left and right arrays (or the two halves)
      myMergeSort(input, temp, start, middle);
      myMergeSort(input, temp, middle+1, end);
      //merge sorted halves 
      merge(input, temp, start, middle, middle+1, end);

    }
  }
  public void merge(int[]arr, int[] temp, int leftStart, int leftEnd, int rightStart, int rightEnd)
  {
    int leftS = leftStart;  //start of left subarray
    int rightS = rightStart; //start of right subarray
    int k = leftStart; //the index of temp
    while(leftS<=leftEnd&&rightS<=rightEnd) //not exceeding index
    {
      if(arr[leftS]<=arr[rightS]) 
      {
        temp[k]=arr[leftS]; //choose the smaller one
        leftS++; //left index advance
      }
      else
      { 
        temp[k]=arr[rightS]; //choose the smaller one
        rightS++; //right index advance
      }
      k++; //increase index of temporary array
    }
    while(leftS<=leftEnd) //if still values left in left array then copy over
    {
      temp[k]=arr[leftS];
      leftS++;
      k++;
    }
    while(rightS<=rightEnd) //if still there are values left in right array then copy all over to the temporary array
    {
      temp[k]=arr[rightS];
      rightS++;
      k++;
    }
    for(int i = leftStart; i<=rightEnd;i++)
    {
      arr[i] = temp[i]; //copy back
    }
  }
  
}