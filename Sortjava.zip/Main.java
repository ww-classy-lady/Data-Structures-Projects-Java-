class Main {
  public static void main(String[] args) {
  //  System.out.println("Hello world!");
    //basically a testing file keke
 /*   Sort a = new Sort();
    int[] h = {2,7,-1,5,6,4};
    int[] k = {2,-1,5,9,6,8,-7};
    int[] d = {15,14,13,12,11};
    int[] o = {11,12,13,14,15};
    int[] g = {9,2,3,0,-3,7,8,12,14,19,10,37,17};
    //all test cases are commented out at first
  //1. UPGRADED QUICK SORT Test case
  //before
  for(int input=0;input<h.length;input++)
  {
      System.out.print(h[input] + " ");
  } 
  System.out.println("\n");
  a.upgradedQuickSort(h, 1, 4);
  //after
  for(int input=0;input<h.length;input++)
  {
      System.out.print(h[input] + " ");
  } 
  
  System.out.println("\n");
  //before
  for(int input=0;input<k.length;input++)
  {
      System.out.print(k[input] + " ");
  } 
  System.out.println("\n");
  a.upgradedQuickSort(k, 1, 1);
  //after
  for(int input=0;input<k.length;input++)
  {
      System.out.print(k[input] + " ");
  } 
  System.out.println("\n");
  //before
  for(int input=0;input<d.length;input++)
  {
      System.out.print(d[input] + " ");
  }
  System.out.println("\n");
  a.upgradedQuickSort(d, 2, 2);
  //after
  for(int input=0;input<d.length;input++)
  {
      System.out.print(d[input] + " ");
  }
  System.out.println("\n"); 
  //BEFORE
  for(int input=0;input<o.length;input++)
  {
      System.out.print(o[input] + " ");
  }
  System.out.println("\n");
  a.upgradedQuickSort(o, 0, 2);
  //AFTER
  
  for(int input=0;input<o.length;input++)
  {
      System.out.print(o[input] + " ");
  }
  System.out.println("\n");
  //BEFORE
  for(int input=0;input<g.length;input++)
  {
      System.out.print(g[input] + " ");
  }
  System.out.println("\n");
  a.upgradedQuickSort(g, 3, 0);
  //AFTER
  for(int input=0;input<g.length;input++)
  {
      System.out.print(g[input] + " ");
  }
  System.out.println("\n"); 
*/
//2. QUICK SORT testcase
    //Before
  /*  for(int input=0;input<g.length;input++)
    {
      System.out.print(g[input] + " ");
    } 
    System.out.println("\n");
    a.quickSort(g);
    //After
    for(int input=0;input<g.length;input++)
    {
      System.out.print(g[input] + " ");
    } 
    System.out.println("\n");
    //Before
    for(int input=0;input<h.length;input++)
    {
      System.out.print(h[input] + " ");
    } 
    System.out.println("\n");
    a.quickSort(h);
    //after
    for(int input=0;input<h.length;input++)
    {
      System.out.print(h[input] + " ");
    } 
    System.out.println("\n");
    //BEFORE
    for(int input=0;input<k.length;input++)
    {
      System.out.print(k[input] + " ");
    } 
    System.out.println("\n");
    a.quickSort(k);
    //AFTER
    for(int input=0;input<k.length;input++)
    {
      System.out.print(k[input] + " ");
    } 
    System.out.println("\n");
    //BEFORE
    for(int input=0;input<d.length;input++)
    {
      System.out.print(d[input] + " ");
    } 
    System.out.println("\n");
    a.quickSort(d);
    //AFTER
    for(int input=0;input<d.length;input++)
    {
      System.out.print(d[input] + " ");
    } 
    System.out.println("\n");
    //BEFORE
    for(int input=0;input<o.length;input++)
    {
      System.out.print(o[input] + " ");
    } 
    System.out.println("\n");
    a.quickSort(o);
    //AFTER
    for(int input=0;input<o.length;input++)
    {
      System.out.print(o[input] + " ");
    } 
    System.out.println("\n"); */
 ////////////////HKDOG
  //3. INSERTION SORT testcase 
    //before
  /*  for(int input=0;input<g.length;input++)
    {
      System.out.print(g[input] + " ");
    } 
    System.out.println("\n");
    a.insertionSort(g);
    //AFter
    for(int input=0;input<g.length;input++)
    {
      System.out.print(g[input] + " ");
    } 

    System.out.println("\n");
    //before
    for(int y=0;y<k.length;y++)
    {
      System.out.print(k[y] + " ");
    }
    System.out.println("\n");
    a.insertionSort(k);
    //after
    for(int y=0;y<k.length;y++)
    {
      System.out.print(k[y] + " ");
    } 

    System.out.println("\n");
    //before
    for(int y=0;y<h.length;y++)
    {
      System.out.print(h[y] + " ");
    }
    System.out.println("\n");
    a.insertionSort(h);
    //after
    for(int y=0;y<h.length;y++)
    {
      System.out.print(h[y] + " ");
    } 

    System.out.println("\n");
    //before
    for(int y=0;y<d.length;y++)
    {
      System.out.print(d[y] + " ");
    }
    System.out.println("\n");
    a.insertionSort(d);
    //after
    for(int y=0;y<d.length;y++)
    {
      System.out.print(d[y] + " ");
    } 

    System.out.println("\n");
    //before
    for(int y=0;y<o.length;y++)
    {
      System.out.print(o[y] + " ");
    }
    System.out.println("\n");
    a.insertionSort(o);
    //after
    for(int y=0;y<o.length;y++)
    {
      System.out.print(o[y] + " ");
    } 
    */

   //4. Merge sort testcase
    //before
 /*  for(int input=0;input<d.length;input++)
    {
      System.out.print(d[input] + " ");
    } 
    System.out.println("\n");
   a.mergeSort(d);
   //AFter
    for(int input=0;input<d.length;input++)
    {
      System.out.print(d[input] + " ");
    } 
   //BEFORE
   System.out.println("\n");
   for(int input=0;input<o.length;input++)
    {
      System.out.print(o[input] + " ");
    } 
    System.out.println("\n");
   a.mergeSort(o);
   //AFter
    for(int input=0;input<o.length;input++)
    {
      System.out.print(o[input] + " ");
    } 
   System.out.println("\n");
   //before
   for(int input=0;input<g.length;input++)
    {
      System.out.print(g[input] + " ");
    } 
    System.out.println("\n");
   a.mergeSort(g);
   //AFter
    for(int input=0;input<g.length;input++)
    {
      System.out.print(g[input] + " ");
    } 
*/
//SELECT TEST CASE
  
  /*  int q = a.select(h, 0);
    
    System.out.println("The 0th largest for h is: \t\t" + q);
    System.out.println("///////////////////////////////////////////////////////");
    //^line for indiction that the next part is from array g (another example)
    for(int i=0; i<g.length;i++)
    {
    System.out.println("The " + i + "th largest for g is: \t\t" + a.select(g,i)); 
    }

  */


  //DONE
  } 
}