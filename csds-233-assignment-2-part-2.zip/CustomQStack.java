//push,pop,and d.empty();
//Wendy Wu
import java.util.*;
import java.util.LinkedList;
import java.util.Queue;
public class CustomQStack{
private Queue<Integer> hi = new LinkedList<Integer>();
public CustomQStack(Queue<Integer> e){
//hi = new Queue<Integer>();
hi = e;
}
public Integer pop(){
int count = hi.size(); //the initial size/num of elements in hi queue
//System.out.println("The size is " + count); 
//^checkpoint to check the functionality of the method
int i = 0; //counter
Queue<Integer> hey = new LinkedList<Integer>(); //new queue to store the edited values
Integer value = 0;
if(empty()==false)
{
  //do the operation
  //first count the number of items in *hi*
  //them dequene and enquene each item into a new queue except the last element. then point *hi* to this new queue
  while(i<(count-1)) 
  {
    value = hi.poll();
    hey.add(value);
    i++;
  }
  value = hi.poll(); //last value (the one going away)
  hi=hey;
}
else
{
  System.out.println("Can't pop anything because no items in the CustomQStack!");
  //no items
  value= null;
}

return value;

}
public void push(Integer n)
{
  hi.add(n); //just add the integer to the customqstack using the add method in queue
  /*int count = hi.size(); // get the num elements in hi
  Queue<Integer> keke = new LinkedList<Integer>();
  int k = 0;
  Integer value = 0;
  while(k<count)
  {
    value = hi.poll();
    keke.add(value);
  }
  keke.add(n);
  hi=keke; */

}
public boolean empty(){
  if(hi.peek()!=null)
  {
    return false; //not null so not empty. empty = false
  }
  else
  {
    return true;
  }
}
public String toString(){
  return (hi.toString()); //re write the to string method

}
}