//Wendy Wu
//10/15/2021
//Helper class Node

public class Node {
private int key; //int value of the node
private Node Left; //left note
private Node Right; // right node

    public Node(int k) { //constructor 
    	key = k; //assigning values
    	Left = null; //initially set to a leave node so lLeft = null
    	Right = null; //initially set to a leave node so Right = null
    }
    public Node(int k , Node L, Node R) //a constructor with left and right node info
    {
    	key = k; //assigning values
    	Left = L; //initially set to a leave node so lLeft = null
    	Right = R; //initially set to a leave node so Right = null
    }
    
    public int getKey()
    {
    	return key; //return the value of the node
    }
    public Node getLeft(){
    	return Left; //return the left node of the current node
    }
    public Node getRight(){
    	return Right; //return the right node of the current node
    }
    public void setKey(int kk) 
	{
		key = kk; //set the key to a new value
	}
	
	public void setLeft(Node left) //set the left node to node left
	{
		Left = left;
	}
	
	public void setRight(Node right) //set the right node to node right
	{
		Right = right;
	}
	public String toString(){ 
		//print the node's key value to the screen
		return "The node's key is: \t\t" + key + " .";
	}
    
    
    
}