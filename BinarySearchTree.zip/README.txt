Helper classes and helper methods:


Helper class Node:

With different methods such as getkey,getLeft, getRight, setKey...
the node class can store the values of keys and node's right child/left child if there are any


Helper Method allKeys (used for kthSmallest):
void allKeys(Node root, ArrayList<Integer>store)

traverse through the binary search tree and store the key values by going through
in order traversal and storing them (well first convert from ints to Integers) in an arraylist (automatically sorts)
Then, in the kthSmallest method, we can copy values (and converting from Integers to ints)
from ArrayList to array and access the index according to k.

Helper method deleteNode
does the deletion with cases with (zero children, 1 child (right or left), and two child)
More comments in the method^
