//Wendy Wu
//Test.java
//10/15/2021

public class Test {

    public static void main(String[] args) {
    	BinarySearchTree a = new BinarySearchTree(); //declare a new BinarySearch Tree called a
    	
    	//////////////////////////////Test case 1(given example)
    	Node root = null; //initially root = null
    	root = a.insert(root, 15); //add root to Binary search tree a
    	Node second = a.insert(root,10); //left node of 15 with value of 10
    	//the inserted node with the information saved to node second and same thing goes for the below list (3rd - 7th):
    	Node third = a.insert(root,20); //right node of 15 with value of 20
    	Node fourth = a.insert(root,8); //left of 10 with value of 8
    	Node fifth = a.insert(root,12); //right of 10 with value of 12
    	Node sixth = a.insert(root,16); //left of 20 with value of 16
    	Node seventh = a.insert(root,25); //right of 20 with value of 25
    	a.inorder(root); //print out the inorder (from smallest to largest) values of the tree
    	int total = a.sum(root); //store the sum of 15+10+20+8+12+16+25 to total
    	System.out.println("The sum is: \t\t" + total + "\n"); //display the sum in a nice way to the screen
    	Node found = a.search(root, 16); //store the node (with key of 16)'s information into node found
    	//^the above will print ("The given key 16 is the left node of the node with key 20")
    	System.out.println(found); //print the key of the found node?
    	int k = 1; //smallest
    	Node smallest = a.kthSmallest(root, k);
    	System.out.println("smallest is : \t\t" + smallest); // prints 8
    	k=2; //second smallest
    	smallest = a.kthSmallest(root, k);
    	System.out.println("second smallest is : \t\t" + smallest); //prints 10
    	k=3; //third smallest...and so on
    	smallest = a.kthSmallest(root, k);
    	System.out.println("third smallest is : \t\t" + smallest);
    	k=4;
    	smallest = a.kthSmallest(root, k);
    	System.out.println("fourth smallest is : \t\t" + smallest);
    	k=5;
    	smallest = a.kthSmallest(root, k);
    	System.out.println("fifth smallest is : \t\t" + smallest);
    	k=6;
    	smallest = a.kthSmallest(root, k);
    	System.out.println("sixth smallest is : \t\t" + smallest);
    	a.inorder(root);
    	Node deleted = a.delete(root,16); //save the deleted node's information (with key of 16) into deleted
    	//^deletes 16
    	System.out.println();
    	a.inorder(root); //print out the tree from smallest to largest (just checking that it is  8 10 12 15 20 25 (without 16)
    //	System.out.println();
    //	a.delete(root,25);
    //	a.search(root, 25);
    //	System.out.println();
    //	a.delete(root,25);
   // 	System.out.println();
    //	a.inorder(root);
    //	System.out.println();
    //	a.delete(root,15);
   // 	System.out.println();
    //	a.inorder(root);
    //	a.search(root,20);
    //	a.search (root,16);
    //	a.search(root,8);
    //	a.search(root,10);
    //	a.search(root,12);
   		a.search(root,25);
   		
   		///////////////////////////////////////////////////////////////////TEST CASE 1 OUTPUT:
   		/*8 10 12 15 16 20 25 The sum is:         106

The given key 16 is the left node of the node with key 20
The node's key is:      16 .
smallest is :       The node's key is:      8 .
second smallest is :        The node's key is:      10 .
third smallest is :         The node's key is:      12 .
fourth smallest is :        The node's key is:      15 .
fifth smallest is :         The node's key is:      16 .
sixth smallest is :         The node's key is:      20 .
8 10 12 15 16 20 25 
8 10 12 15 20 25 The given key 25 is the right node of the node with key 20 */

   		//^the given key 25 is the right node of the node with key 20;
    //	a.search (root, 16); 
    
    
    
    
    	//////////////////////////TEST CASE 2: (i will comment out test case 1 when testing test case 2)
    /*	Node root = null; //initially root = null
    	root = a.insert(root, 10); //insert the first node into the tree
    	a.insert(root,13);
    	System.out.println();
    	a.inorder(root);
    	a.insert(root,8);
    	System.out.println();
    	a.inorder(root);
    	a.insert(root,17);
    	System.out.println();
    	a.inorder(root);
    	a.insert(root,9);
    	System.out.println();
    	a.inorder(root);
    	a.insert(root,2);
    	System.out.println();
    	a.inorder(root);
    	a.insert(root,12);
    	System.out.println();
    	a.inorder(root);
    	//output^
    	//10 13 
		//8 10 13 
		//8 10 13 17 
		//8 9 10 13 17 
		//2 8 9 10 13 17 
		//2 8 9 10 12 13 17 
		a.search(root,10);
		a.search(root,13);
		a.search(root,12);
		a.search(root,17);
		a.search(root,8);
		a.search(root,2);
		a.search(root,9);
		// Correct Output
		// *The node is the root node //meaning the node with key 10
//The given key 13 is the right node of the node with key 10
//The given key 12 is the left node of the node with key 13
//The given key 17 is the right node of the node with key 13
//The given key 8 is the left node of the node with key 10
//The given key 2 is the left node of the node with key 8
//The given key 9 is the right node of the node with key 8
		
		a.delete(root,13);
		a.inorder(root);
		a.search(root,10);
		a.search(root,12);
		a.search(root,17);
		a.search(root,8);
		a.search(root,2);
		a.search(root,9);
		System.out.println("The 3rd smallest:\t\t" + (a.kthSmallest(root,3)).getKey()); */
		/////////////////Test case 3:
	/*	Node root = null; //initially root = null
		a.inorder(root);
    	root = a.insert(root, 10); //insert the first node into the tree
    	a.inorder(root); //prints 10 
    	root=a.delete(root,10); //delete this single node 10 and root should be set to null
    	a.inorder(root);// prints nothing*/
    	
    }
    
    
}