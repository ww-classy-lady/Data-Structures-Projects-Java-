//Wendy Wu
//10/15/2021
//BST class

//extra implementations
import java.util.List;
import java.util.ArrayList;
public class BinarySearchTree {
private Node first; //will need for delete method. Basically will store the root so that helper deleteNode can use this for an operation
   /* public BinarySearchTree() {
    	
    }*/
    public Node insert(Node root, int key)
    {
    	Node one;
    	Node add = null; //will return this node
    	Node trav = root; //traversal node pointer
    	if(trav==null)  //add as root node
    	{
    		one = new Node(key);
      		add = one; //set the add to root node and will return add
    	}
    	else//root is occupied 
    	{
    		while(trav!=null)
    		{
    		
    		if(key>trav.getKey()) //go right
    		{
    			if(trav.getRight()==null)  //found a spot on the right and ready to insert
    			{
    				add = new Node(key); 
    				trav.setRight(add); //add the new node with key value to trav (which will be the parent of this new node) 's right
    				return add; //return this inserted node
    				
    			}
    			else
    			{
    				trav = trav.getRight(); //set the current root to right node and repeat until found a place to add 
    			}
    		}
    		else if(key<trav.getKey()) // go left
    		{
    			if(trav.getLeft()==null) //found a spot on the left and ready to insert
    			{
    				add = new Node(key);
    				trav.setLeft(add); //add the new node with key value to trav (which will be the parent of this new node) 's left
    				return add; //return this inserted node
    				
    			}
    			else
    			{
    				trav = trav.getLeft(); //set the current root to right node and repeat until found a place to add 
    			}
    		}
    		}
    		
    	}
    	return add; //return the pointer to an added node
    } 
    public void inorder(Node root) //basically a print method that prints the tree in order
    {
    	Node start = root;
    	if(start!=null){
    	
    		inorder(start.getLeft()); //calls the method recursively until found the most left and will eventually backtrack
    		System.out.print(start.getKey() + " "); //print out the root
    		inorder(start.getRight()); //calls the method recursively and will print out right only after the left recursive call is done
    	}
    	else
    	{
    		return;
    	}
    }
    public int sum(Node root)
    {
    	Node begin = root;
    	int total = 0; 
    	if(begin == null) //stopping condition
    	{
    		return 0;
    	}
    	else
    	{
    	//recursively adding all of the nodes in the tree
    		total= total + begin.getKey(); //root value 
    		
    		total= total + sum(begin.getLeft()); //left value
    		total= total + sum(begin.getRight()); //right value
    	}
    	return total;
    }
    public Node search(Node root, int key)
    {
    	Node trav = root;
    	Node assign = null;
    	Node parent = null;
    	boolean right =false; //know if it is the right node or not
    	boolean left = false; //know if it is the left node or not
    	boolean stop = false; //know if stopping condition is reached
    	if(trav==null) //if tree is empty
    	{
    		assign = null;
    		stop = true;
    	}
    	else 
    	{
    		while((trav!=null)&&(stop ==false)) //while we dont need to stop and haven't found the node yet
    		{
    		
    		if((key == (trav.getKey()))&&(parent ==null)) //it is the root's key
    		{
    			assign = trav;
    			System.out.println("\nThe node is the root node");
    			stop = true;
    		}
    		else if(key==(trav.getKey())&&(parent!=null)&&(right==true)) //if went right and found the node
    		{
    			assign = trav;
    			System.out.println("The given key " + key + " is the right node of the node with key " + parent.getKey() );
    			stop = true; //found the node so stop now
    		}
    		else if(key==(trav.getKey())&&(parent!=null)&&(left==true)) //if went left and found the node
    		{
    			assign = trav;
    			System.out.println("The given key " + key + " is the left node of the node with key " + parent.getKey() );
    			stop = true;
    		}
    		else if (key>(trav.getKey())) //traverse right tree 
    		{ //didn't found node with value key yet and key is greater than the current node's key value then go right
    			parent = trav; 
    			trav = trav.getRight();// go right
    			right = true;
    			left = false; //went right so need to set left to false in case the previous iteration went left
    			
    			
    		}
    		else if(key<(trav.getKey())) //traverse left tree
    		{ //^same logic as right except now go left 
    			parent = trav;
    			trav = trav.getLeft(); //go left
    			left = true;
    			right = false;//went left so need to set right to false in case the previous iteration went right
    		}
    		}
    	}
    	return assign; //return the found node
    }
    public Node kthSmallest(Node root, int k){
    	ArrayList<Integer> num = new ArrayList<Integer>(); //use an array list
    	
    	Node result=null;
    	allKeys(root,num); //USED HELPER METHOD
    	int[] calc = new int[num.size()];
    	for(int i =0;i<num.size();i++) //traverse the arraylist
    	{
    		calc[i]= (num.get(i)).intValue(); //put all values (Integer convert to ints)into an array
    	}
    	result = new Node(calc[k-1]); //get the key value that is index at k-1 because 1st smallest would be at index 0. Create a new node with the key 
    	return result;
    	
    	
    }
    //HELPER METHOD FOR kthSMALLEST
    public void allKeys(Node root, ArrayList<Integer> store) //helper method for kthSmallest
    {
    	if(root!=null)//basically in order traverse and add to arrayList (in order traverse automatically sorted from smallest to largest)
    	{
    		allKeys(root.getLeft(),store); //recursion
    		store.add(new Integer(root.getKey()));
    		allKeys(root.getRight(),store);
    	}
    }
   	public Node delete(Node root, int key){
   		Node parent = null;
   		Node trav = root; //auto set to root
   		Node result = null;
   		first = root;
   		if(root.getKey()==key) //if the deleted value is at the root
   		{
   			if(root.getRight()==null&&root.getLeft()==null)
   			{
   				root = null; //delete a single root node
   				return null;
   			}
   		}
   		//search for the node and keep track of parent
   		while((trav!=null)&&(trav.getKey()!=key)){ // if to be deleted isnt at root and tree isn't null, keep searching
   			parent = trav;
   			if(key<trav.getKey())//goleft
   			{
   				trav=trav.getLeft(); //change to left node
   			}
   			else if(key>trav.getKey()) // go right
   			{
   				trav = trav.getRight();
   			}
   		}
   		if(trav == null) //if nothing to delete in the tree, just return null
   		{
   			return null;
   		}
   		else
   		{
   			result = trav; //the node to be deleted
   			deleteNode(trav, parent); //calls helpter method
   			return result; //return the deleted node
   		}
   		
   	}

    public void deleteNode(Node delete, Node parent)//helper method for delete method (with slight modification from the taught method)
    {
    	
    //	Node trav = root;
    	if((delete.getLeft()==null)||(delete.getRight()==null)) //one child or leave node
    	{
    		Node toDeleteChild = null; 
    		if(delete.getLeft()!=null) //exist a left child of delete
    		{
    			toDeleteChild = delete.getLeft();
    		}
    		else if(delete.getRight()!=null)//exist a right child of delete
    		{
    		 	toDeleteChild = delete.getRight();
    		}
    		
    		if(delete==first) //if it is the root(which was set to the node first) and have a single child (right or left)/no child
    		{
    			first = toDeleteChild;
    		}
    		else if(delete.getKey()<parent.getKey()){ //delete node is on the left side
    			parent.setLeft(toDeleteChild); //set to the child of the deleted node
    		}
    		else if(delete.getKey()>parent.getKey())//delete node is on the right side
    		{
    			parent.setRight(toDeleteChild); //set to the child of the deleted node
    		}
    		
    	}
    	else //when there are two children of the want-to-be deleted node
    	{
    		
    			Node swapParent = delete; // point the parent to the want to delete node
    			Node swap = delete.getRight(); //go to right child of delete 
    			if(swap.getLeft()!=null){ //if the left node of delete's right node exist
    			
    			while(swap.getLeft()!=null){
    				swapParent=swap;
    				swap = swap.getLeft();
    			}
    			delete.setKey(swap.getKey()); //15 now set to 20
    			
    			deleteNode(swap,swapParent); //continue calling method in a recursive way
    			}
    			else if((swap.getLeft()==null)&&swap.getRight()!=null){ //if the left of delete's right is not there and the right of delete's right exist
    				delete.setKey(swap.getKey()); //delete's right is set to the right child 
    				delete.setRight(swap.getRight()); //delete points to its right child's right child (thus deletes delete's right child 
    			}
    			else if((swap.getLeft()==null)&&(swap.getRight()==null)){ //if both children of the right child is null
    				delete.setKey(swap.getKey()); //set delete's key to right child
    				delete.setRight(null); //then right child become null
    			}
    		
    	}
    	
    }
    
}