//Part 1
//Wendy Wu
//Purpose: create an algorithm to reverse a Linkedlist that is filled with integers
import java.util.*;
class Main {

  public static void main(String[] args) {
    LinkedList<Integer> hehe = new LinkedList<Integer>();
    //just adding some values to test and stuff
    hehe.add(1);
    hehe.add(2);
    hehe.add(3);
    hehe.add(4);
    hehe.add(5);
    hehe.add(6); //only for even cases. this will be tested
    //Linkedlist initially will look like this [1,2,3,4,5,6]
    System.out.println(hehe); //before reverse
    System.out.println(hehe.get(0)); //get the first value before reverse
    System.out.println(hehe.size()); //get the size of the LinkedList
//************************IMPORTANT: below is the code for printing the LinkedList in reverse!!!******************
  //The part below is the reverse operation code:
    int left = 0; //set the right
    int right = 0;
    for(int i = 0; i<((hehe.size())/2); i++) //traverse half of the list to swap left and right values 
    {
      left = hehe.get(i); //get the value on the left end
      right = hehe.get(hehe.size()-(i+1)); //get the value on the right most end
      hehe.set(i, right); //set the right node to the value of the left
      hehe.set((hehe.size()-(i+1)),left); //set the value of the left to the right node's previous value
    }
    System.out.println(hehe); //print the list after node
    //Linkedlist after reverse = [6,5,4,3,2,1]
    
  }
}