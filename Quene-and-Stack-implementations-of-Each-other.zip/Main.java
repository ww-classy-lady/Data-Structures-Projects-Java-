//Wendy Wu
//testing file for customqstack and customsQueue
//Majority of test cases are commented out
import java.util.*;
import java.util.Queue;
import java.util.LinkedList;
class Main {
  public static void main(String[] args) {
    //Part 2a
  /* Queue<Integer> her = new LinkedList<Integer>();
    Integer x;
    her.add(5);
    her.add(6);
    her.add(7);
    her.add(8);
    her.add(9);
    CustomQStack he = new CustomQStack(her);
    System.out.println(her); //before change;
    x = he.pop();
    System.out.println(x);
    //9
    x = he.pop();
    System.out.println(x);
    //8
    System.out.println(he.empty()); //false
    he.push(1);
    
    System.out.println(he);
    x = he.pop();
    System.out.println(x); */
    //1

    //my own test case below:
  /*  Integer x = he.pop(); //should pop 5
    Integer y = he.pop(); //4
    Integer z= he.pop();//3
    Integer w = he.pop();//2
    Integer last= he.pop();//1
    Integer non = he.pop(); 
    System.out.println(x);
    System.out.println(y);
    System.out.println(z);
    System.out.println(w);
    System.out.println(last);
    System.out.println(non); */ 
    
    //Part 2b
    Integer x;
    Stack<Integer> e = new Stack<Integer>();
    e.push(5);
    e.push(6);
    e.push(7);
    e.push(8);
    e.push(9);
    //Queue will look like this: 5,6,7,8,9
    System.out.println(e);
    CustomSQueue d = new CustomSQueue(e);
    x=d.poll();
    //^first number of Queue is 5
    System.out.println(x);
    //5^
    x=d.poll();
    System.out.println(x);
    //6^
    d.add(2);
    //Add 2 to the end of the Queue
    System.out.println(d);
    //[7,8,9,2] is the final queue after all changes




  }
}