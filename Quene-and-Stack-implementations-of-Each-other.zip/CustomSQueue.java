//Wendy Wu
//Purpose:Implemenet Stack using Queue data structures(poll,add, toString)
import java.util.Stack;
public class CustomSQueue{
  private Stack<Integer> you;
  public CustomSQueue(Stack<Integer> star){
    you = star;
  }
  public void add(Integer m){
    //basically add to the end of the queue (but using stack method push)
    you.push(m);
    //adding to the top/latest
  }
  public Integer poll(){
    //basically popping the first element to the screen and deleting it from the queue using stacks 
    //use push and pop of stack to complete this operation
    Stack<Integer> middle = new Stack<Integer>();
    Stack<Integer> last = new Stack<Integer>();
    Integer pop=0;
    if(you.empty()==false)
    {
      //if not empty
      while(you.empty()==false)
      {
        middle.push(you.pop()); //add all the elements to the middle one
      }
      pop=middle.pop(); //pop off the top, which is the initial first element of you 
      while(middle.empty()==false)
      {
        last.push(middle.pop()); //reverse the values by transfering from middle stack to last stack
      }
      you = last; //reset pointer of you to the edited/changed stack last
    }
    else
    {
      System.out.println("The CustomSQueue is empty and we can't use poll() ");
      pop = null;
    }
    return pop;
  }
  public String toString(){
    return (you.toString()); //printing all the values in the "you" stack
  }
}
